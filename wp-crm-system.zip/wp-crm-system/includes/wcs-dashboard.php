<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
?>
<div class="wrap">
	<div class="wpcrm-dashboard-wrapper">
		<?php do_action( 'wpcrm_system_custom_dashboard_boxes' ); ?>
	</div>
</div>
