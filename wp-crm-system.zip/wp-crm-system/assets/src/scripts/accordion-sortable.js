jQuery(document).ready(function() {
	jQuery( "#accordion" ).accordion({
		collapsible: true,
		active: false
	});
});