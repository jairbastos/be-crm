jQuery(document).ready(function() {
	jQuery( "#wp-crm-system-accordion" ).accordion({
		collapsible: true,
		active: false
	});
});
